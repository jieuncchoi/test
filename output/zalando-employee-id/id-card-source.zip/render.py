"""Export vector print PDFs, 300-dpi previews, and the two-card mockup."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import shutil

import fitz
from PIL import Image
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parent
handler = partial(SimpleHTTPRequestHandler, directory=str(root))
with ThreadingHTTPServer(('127.0.0.1', 0), handler) as server, TemporaryDirectory() as temp:
    Thread(target=server.serve_forever, daemon=True).start()
    url = f'http://127.0.0.1:{server.server_port}/'
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=shutil.which('chromium'), args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 960}, device_scale_factor=2)
        for variant in ('mockup', 'black', 'orange'):
            page.goto(url if variant == 'mockup' else f'{url}?card={variant}', wait_until='networkidle')
            page.evaluate("async () => { await document.fonts.ready; await Promise.all([...document.images].map(i=>i.decode())); }")
            if variant == 'mockup':
                page.screenshot(path=str(root/'id-card-mockup.png'))
                continue
            result = page.evaluate("""() => {
              const box = node => node.getBoundingClientRect();
              const card = box(document.querySelector('.card'));
              const name = document.querySelector('h1');
              const ink = document.createRange();
              ink.selectNodeContents(name);
              const logo = box(document.querySelector('.card img'));
              return { name: name.textContent, role: document.querySelector('p').textContent,
                within: box(ink).right < card.right - logo.left + .1,
                height: logo.height, clearance: Math.min(logo.left, card.right-logo.right, logo.top, card.bottom-logo.bottom) };
            }""")
            print(variant, result)
            assert result['name']=='Alex Morgan' and result['role']=='Creative Director'
            assert result['within'] and result['height']>=24 and result['clearance']>=result['height']/2
            cdp=page.context.new_cdp_session(page)
            cdp.send('DOM.enable'); cdp.send('CSS.enable')
            doc=cdp.send('DOM.getDocument')['root']['nodeId']
            for selector in ['h1','p']:
                node=cdp.send('DOM.querySelector',{'nodeId':doc,'selector':selector})['nodeId']
                fonts=cdp.send('CSS.getPlatformFontsForNode',{'nodeId':node})['fonts']
                assert fonts and all(f['familyName']=='Zalando Sans' and f['isCustomFont'] for f in fonts)
            stage=Path(temp)/f'{variant}.pdf'
            page.pdf(path=str(stage),prefer_css_page_size=True,print_background=True)
            with fitz.open(stage) as src, fitz.open() as out:
                assert len(src)==1
                sheet=out.new_page(width=54*72/25.4,height=86*72/25.4)
                sheet.show_pdf_page(sheet.rect,src,0,keep_proportion=False)
                assert sheet.get_text().splitlines()==['Alex Morgan','Creative Director']
                out.save(root/f'id-card-{variant}.pdf',garbage=4,deflate=True)
                pix=sheet.get_pixmap(dpi=300,alpha=False)
                Image.frombytes('RGB',(pix.width,pix.height),pix.samples).save(root/f'id-card-{variant}.png',dpi=(300,300))
mock=Image.open(root/'id-card-mockup.png')
assert mock.size==(2880,1920)
