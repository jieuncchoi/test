"""Render the browser plates, append the official logo sequence, and export stills."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import shutil
import subprocess
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
STEM = 'zalando-brand-motion'
handler = partial(SimpleHTTPRequestHandler, directory=str(ROOT))

def ffmpeg(*args):
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,args)],check=True)

with ThreadingHTTPServer(('127.0.0.1',0),handler) as server, TemporaryDirectory() as tmp:
    Thread(target=server.serve_forever,daemon=True).start()
    frames=Path(tmp)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1920,'height':1080})
        page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
        page.evaluate("async()=>{await document.fonts.load('108px Zalando Sans'); await Promise.all([...document.images].map(i=>i.decode()));}")
        for frame in range(113):
            page.evaluate('(frame)=>window.renderFrame(frame)',frame)
            page.screenshot(path=str(frames/f'{frame:03}.png'),timeout=15000)
    ffmpeg('-framerate',25,'-i',frames/'%03d.png','-i',ROOT/'assets/outro-official.mp4',
           '-filter_complex','[0:v]setsar=1,format=yuv420p[a];[1:v]trim=start_frame=45:end_frame=107,setpts=N/(25*TB),scale=1920:1080:flags=lanczos,setsar=1,format=yuv420p[b];[a][b]concat=n=2:v=1:a=0,setpts=N/(25*TB),fps=25,tpad=stop_mode=clone:stop=1,trim=end_frame=175',
           '-an','-c:v','libx264','-preset','medium','-crf',17,'-movflags','+faststart',ROOT/f'{STEM}.mp4')
    for index,label in [(0,'first'),(174,'last')]:
        ffmpeg('-i',ROOT/f'{STEM}.mp4','-vf',f'select=eq(n\\,{index})','-frames:v',1,ROOT/f'{STEM}-{label}.png')
