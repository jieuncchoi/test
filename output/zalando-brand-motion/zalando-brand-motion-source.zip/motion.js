const wordmark = document.querySelector('.wordmark');
const model = document.querySelector('.model');
const headline = document.querySelector('h1');
const copy = 'Style your way.';
const tail = Array.from(copy.slice(-5), letter => {
  const span = document.createElement('span');
  span.textContent = letter;
  return span;
});
headline.append(copy.slice(0, -5), ...tail);

const clamp = value => Math.max(0, Math.min(1, value));
const smoothstep = value => value * value * (3 - 2 * value);

/* Frame-based entry lets the renderer capture exactly 25 frames per second. */
window.renderFrame = frame => {
  const intro = frame < 50;
  const time = (frame - 50) / 25;
  const progress = smoothstep(clamp(time / 1.72));
  wordmark.hidden = !intro;
  headline.hidden = intro || time < .44;
  model.style.transform = `translateX(${530 + 510 * progress}px)`;
  tail.forEach((letter, i) => {
    const reveal = clamp((time - .48 - i * .075) / .15);
    letter.style.opacity = reveal * reveal;
  });
};
window.renderFrame(0);
