"""Derive a subject alpha matte from the supplied portrait without repainting RGB."""
from pathlib import Path
import cv2
import numpy as np
from PIL import Image

root = Path(__file__).resolve().parent / 'assets'
portrait = np.asarray(Image.open(root / 'portrait-original.png').convert('RGB'))
outline = [(148,701),(153,655),(166,639),(174,575),(106,550),(124,493),(141,451),(125,432),(118,402),(121,365),(131,330),(145,304),(147,283),(160,254),(182,240),(230,239),(249,225),(246,220),(227,214),(216,202),(212,186),(217,171),(222,158),(230,139),(244,119),(259,99),(280,88),(294,86),(311,91),(322,102),(335,122),(345,147),(354,177),(354,192),(345,207),(327,220),(318,231),(319,253),(346,277),(372,288),(395,314),(406,334),(421,373),(427,402),(423,451),(436,468),(427,489),(421,527),(420,570),(401,602),(396,701)]
prior = np.zeros(portrait.shape[:2],np.uint8)
cv2.fillPoly(prior,[np.array(outline)*2],255)
band=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(37,37))
inside=cv2.erode(prior,band)>0
outside=cv2.dilate(prior,band)==0
mask=np.where(prior>0,cv2.GC_PR_FGD,cv2.GC_PR_BGD).astype(np.uint8)
mask[inside]=cv2.GC_FGD
mask[outside]=cv2.GC_BGD
cv2.grabCut(portrait,mask,None,np.zeros((1,65)),np.zeros((1,65)),4,cv2.GC_INIT_WITH_MASK)
alpha=(np.isin(mask,[cv2.GC_FGD,cv2.GC_PR_FGD])*255).astype(np.uint8)
alpha=cv2.GaussianBlur(alpha,(5,5),.85)
Image.fromarray(np.dstack([portrait,alpha])).save(root/'portrait-cutout.png')
