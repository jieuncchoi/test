const portrait = document.querySelector('.portrait');
const typography = document.querySelector('.typography');
const headline = document.querySelector('h1');
const copy = 'Style your way.';
const tail = Array.from(copy.slice(-5), character => {
  const glyph = document.createElement('span');
  glyph.textContent = character;
  return glyph;
});
headline.append(copy.slice(0, -5), ...tail);

// The official examples use a fast ease-in reveal on the tail, followed by a hard cut.
window.renderFrame = frame => {
  portrait.hidden = frame >= 50;
  typography.hidden = frame < 50;
  const elapsed = (frame - 50) / 25;
  tail.forEach((glyph, index) => {
    const progress = Math.min(1, Math.max(0, (elapsed - index * .066) / .16));
    glyph.style.opacity = progress ** 2;
  });
};
window.renderFrame(0);
