"""Render portrait and title plates, then sequence the complete official videos."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import shutil
import subprocess
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
STEM = 'zalando-brand-motion-full-assets'
def ffmpeg(*args):
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,args)],check=True)

with ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(ROOT))) as server, TemporaryDirectory() as tmp:
    Thread(target=server.serve_forever,daemon=True).start()
    frames=Path(tmp)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1920,'height':1080})
        page.goto(f'http://127.0.0.1:{server.server_port}/',wait_until='networkidle')
        page.evaluate("async()=>{await document.fonts.load('152px Zalando Sans'); await Promise.all([...document.images].map(i=>i.decode()));}")
        for i in range(113):
            page.evaluate('(i)=>window.renderFrame(i)',i)
            page.screenshot(path=str(frames/f'{i:03}.png'))
        page.evaluate("""() => {
          const grid=document.createElementNS('http://www.w3.org/2000/svg','svg');
          grid.setAttribute('viewBox','0 0 1920 1080');
          grid.style.cssText='position:absolute;inset:0;width:100%;height:100%';
          for(let col=0;col<12;col++) for(let row=0;row<6;row++) {
            const r=document.createElementNS(grid.namespaceURI,'rect');
            for(const [k,v] of Object.entries({x:32.4+155.95*col,y:32.4+171.9*row,width:139.75,height:155.7,fill:'none',stroke:'#126c88','stroke-width':2}))r.setAttribute(k,v);
            grid.append(r);
          }
          document.querySelector('#stage').append(grid);
        }""")
        page.screenshot(path=str(ROOT/'motion-grid-check.png'))
    chain=('[0:v]scale=1920:1080:flags=lanczos,setsar=1,format=yuv420p[a];'
           '[1:v]setsar=1,format=yuv420p[b];'
           '[2:v]scale=1920:1080:flags=lanczos,setsar=1,format=yuv420p[c];'
           '[a][b][c]concat=n=3:v=1:a=0,setpts=N/(25*TB)')
    ffmpeg('-i',ROOT/'assets/intro-official.mp4','-framerate',25,'-i',frames/'%03d.png',
           '-i',ROOT/'assets/outro-official.mp4','-filter_complex',chain,
           '-r',25,'-an','-c:v','libx264','-crf',17,'-movflags','+faststart',ROOT/f'{STEM}.mp4')
    for i,label in [(0,'first'),(332,'last')]:
        ffmpeg('-i',ROOT/f'{STEM}.mp4','-vf',f'select=eq(n\\,{i})','-frames:v',1,ROOT/f'{STEM}-{label}.png')
