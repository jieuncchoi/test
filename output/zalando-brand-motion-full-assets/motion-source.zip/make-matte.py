"""Create a subject-only overlay without changing the source RGB values."""
from pathlib import Path
import cv2
import numpy as np
from PIL import Image

assets = Path(__file__).resolve().parent / 'assets'
rgb = np.array(Image.open(assets / 'full-body-model.png').convert('RGB'))
seed = (cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY) < 177).astype(np.uint8)
count, labels, stats, _ = cv2.connectedComponentsWithStats(seed)
assert count > 1
subject = (labels == 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])).astype(np.uint8)
contours, _ = cv2.findContours(subject, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
cv2.drawContours(subject, contours, -1, 1, cv2.FILLED)
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (35,35))
mask = np.where(subject, cv2.GC_PR_FGD, cv2.GC_PR_BGD).astype(np.uint8)
mask[cv2.erode(subject,kernel)>0] = cv2.GC_FGD
mask[cv2.dilate(subject,kernel)==0] = cv2.GC_BGD
cv2.grabCut(rgb,mask,None,np.zeros((1,65)),np.zeros((1,65)),4,cv2.GC_INIT_WITH_MASK)
alpha = cv2.GaussianBlur((np.isin(mask,[cv2.GC_FGD,cv2.GC_PR_FGD])*255).astype(np.uint8),(5,5),.8)
Image.fromarray(np.dstack((rgb,alpha))).save(assets/'model-matte.png')
